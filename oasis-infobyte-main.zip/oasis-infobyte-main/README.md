# OIBSIP - Oasis Infobyte Intern Program
OASIS INFOBYTE offers a variety of website design and development services. Got the chance for 1 month intern of Web development and design.
There are 3 task given to complete. After completing all tasks, if everything looks fine, the intern will be certified. Glad to be a part of OASIS INFOBYTE intern program.


## Task1 - Calculator
A Calculator created under the virtual internship program of Oasis Infobyte. <br>
[Live](https://devvsakib.github.io/oasis-infobyte/Task1)

## Task2 - Tribute Page
A tribute page created under the virtual internship program of Oasis Infobyte. <br>
[Live](https://devvsakib.github.io/oasis-infobyte/Task2)

## Task3 - Todo webapp
A TO-DO app created under the virtual internship program of Oasis Infobyte. <br>
[Live](https://devvsakib.github.io/oasis-infobyte/Task3)
